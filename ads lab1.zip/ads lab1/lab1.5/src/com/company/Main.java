package com.company;
import java.util.Scanner;

public class Main {


            public static void main (String args[])
            {
                fibonacci sc = new fibonacci();
                int n = 9;
                System.out.println(sc.fib(n));
            }
        }


    class fibonacci
    {
        static int fib(int n)
        {
            if (n <= 1)
                return n;
            return fib(n-1) + fib(n-2);
        }
}