package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
            int n = in.nextInt();
    boolean flag = false;
    for(int i = 2; i <= n/2; i++){
          if(n % 2 == 0){
              flag = true;
              System.out.println(n + ":Composite number");
              break;
          }
    }
        if(!flag)
            System.out.println(n + ":Prime number");
    }
}
