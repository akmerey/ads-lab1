package com.company;
import java.util.Scanner;

public class Main {
    public static void findMin(int[] arr) {
        int min = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < min)
                min = arr[i];
        }
        System.out.println(min);
    }
    public static void main(String[] args) {
	int[] arr = {10, 1, 32, 3, 45};
    int arr_size = 5;
    findMin(arr);
    }
}
