package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
    int n = in.nextInt();
    double[] arr = new double[n];
    double total = 0;
    for(int i = 0; i < arr.length; i++) {
        arr[i] = in.nextDouble();
    }
        in.close();
        for(int i=0; i<arr.length; i++){
            total = total + arr[i];
        }
        double average = total / arr.length;

        System.out.format("The average is: "+ average);
    }
}
