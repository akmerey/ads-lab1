package com.company;
import java.util.Scanner;

public class Power {
        public static void main(String[] args) {
            Scanner in = new Scanner(System.in);
            int a = in.nextInt();
                    int b = in.nextInt();
            int result = power(a, b);

            System.out.println( result);
        }
        public static int power(int a, int b) {
            if (b != 0) {

                // recursive call to power()
                return (a * power(a,b - 1));
            }
            else {
                return 1;
            }
        }
    }


