package com.company;
import java.util.Scanner;

public class Main {
    static int [][] arr = new int[1001][1001];
    static int gcd(int a, int b)
    {
        if (a == 0)
            return b;
        if (b == 0)
            return a;
        if (a == b)
            return a;
        if(arr[a][b] != -1)
            return arr[a][b];
        if (a > b)
            arr[a][b] = gcd(a-b, b);
        else
            arr[a][b] = gcd(a, b-a);
        return arr[a][b];
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        for(int i = 0; i < 1001; i++) {
            for(int j = 0; j < 1001; j++) {
                arr[i][j] = -1;
            }
        }
        int a = in.nextInt(), b = in.nextInt();
        System.out.println(gcd(a, b));
    }
}
